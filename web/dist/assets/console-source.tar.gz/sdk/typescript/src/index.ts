export type Effect = "none" | "applied" | "partial" | "unknown"
export type OperationState = "queued" | "dispatching" | "observing" | "succeeded" | "failed" | "cancelled" | "recovery_required"
export interface ErrorDetail {
  code?: string
  message?: string
  effect?: Effect
  retry?: string
  operation_id?: string
  [key: string]: unknown
}
export interface Operation {
  operation_id: string
  state: OperationState
  machine_id?: string
  kind: string
  stage: string
  effect: Effect
  binding_generation?: number
  error?: ErrorDetail | null
  result?: Record<string, unknown> | null
}
export interface Capability { supported: boolean; reason_code?: string | null; message?: string; verified_profile?: string }
export interface Control {
  control_epoch: string
  runtime_version?: string
  build?: string
  maintenance?: boolean
  csrf_token?: string
  capabilities?: Record<string, Capability>
}
export interface Resources { cpu_count: number; memory_mib: number; storage_gib: number; overlay_gib: number }
export interface IdlePolicy { enabled: boolean; timeout_seconds: number }
export interface CreateMachine {
  name: string
  template_id: string
  resources?: Resources
  idle_policy?: IdlePolicy
  start?: boolean
}
export interface Machine extends CreateMachine {
  machine_id: string
  spec?: { resources?: Resources }
  revision: number
  binding_generation: number
  observed_state: string
  availability: string
  desired_power: string
  operation_id?: string | null
  observed_at?: string | null
  last_user_activity_at?: string | null
  blocked_reasons?: string[]
  capabilities?: Record<string, Capability>
  runtime_identity?: Record<string, unknown> | null
  runtime_name?: string
  guest_management_status?: string
  state_reason?: unknown
  binding?: {
    binding_id?: string
    runtime_identity?: Record<string, unknown> | null
    state_reason?: unknown
    guest_management_evidence?: { ssh_ready?: boolean; ssh_host_key?: string }
  }
  keep_running?: boolean
}
export interface TaskSpec {
  argv: string[]
  cwd?: string
  user?: string
  env?: Record<string, string>
  task_key?: string
  output_limit?: number
  output_policy?: string
}
export interface Task {
  task_id?: string
  id?: string
  machine_id: string
  state: "accepted" | "starting" | "running" | "cancelling" | "succeeded" | "failed" | "cancelled" | "unknown" | "interrupted"
  observed_at?: string
  exit_code?: number | null
  origin_machine_id?: string
  origin_task_id?: string
  revision?: number
  operation_id?: string
}
export interface ServiceSpec {
  name: string
  protocol: "http" | "https" | "ssh" | "tcp-mtls"
  guest_port: number
  readiness?: unknown
  auth?: unknown
}
export interface Service extends ServiceSpec {
  service_id: string
  machine_id: string
  revision: number
  public_host?: string
  public_port?: number
  enabled?: boolean
  [key: string]: unknown
}
export interface Snapshot {
  snapshot_id: string
  source_machine_id?: string
  revision?: number
  purpose: "clone" | "recovery"
  task_content: string
  state: string
  label?: string
  sha256?: string
  size_bytes?: number
  created_at?: string
  [key: string]: unknown
}
export interface TokenSpec {
  label: string
  scope: { access: "read" | "manage" | "tunnel"; machine_id?: string }
  expires_at?: string
}
export interface Token extends TokenSpec {
  token_id: string
  revision: number
  created_at: string
  revoked_at?: string
  token?: string
}
export interface Mutation { epoch: string; key: string }
export interface WriteOptions { method?: string; revision?: number; intent?: Mutation; signal?: AbortSignal }
export interface MachineWriteOptions extends WriteOptions { generation?: number }
export interface Page<T> { items: T[]; next_cursor?: string }
export interface TaskChunk { start: number; next: number; gap: boolean; bytes: Uint8Array }
export interface PlatformEvent { id: string; type: string; data: unknown }
export interface StreamTicket { ticket: string; protocol?: string }
export const terminalStates = new Set<OperationState>(["succeeded", "failed", "cancelled", "recovery_required"])

export class PlatformError extends Error {
  constructor(readonly status: number, readonly detail: ErrorDetail) {
    super(detail.message ?? `HTTP ${status}`)
    this.name = "PlatformError"
  }
}

const segment = encodeURIComponent
export function machine(id: string) { return "machines/" + segment(id) }
export function task(id: string) { return "tasks/" + segment(id) }
export function snapshot(id: string) { return "snapshots/" + segment(id) }
export function service(id: string) { return "services/" + segment(id) }
export function operation(id: string) { return "operations/" + segment(id) }

function pause(ms: number, signal?: AbortSignal): Promise<void> {
  return new Promise((resolve, reject) => {
    signal?.throwIfAborted()
    const timer = setTimeout(() => {
      signal?.removeEventListener("abort", abort)
      resolve()
    }, ms)
    const abort = () => {
      clearTimeout(timer)
      reject(signal?.reason)
    }
    signal?.addEventListener("abort", abort, { once: true })
  })
}

function withQuery(path: string, params: Record<string, string>) {
  return path + (path.includes("?") ? "&" : "?") + new URLSearchParams(params)
}

export class Client {
  private readonly base: URL
  private csrf?: string

  constructor(url: string, private readonly token?: string) {
    this.base = new URL(url.replace(/\/$/, "") + "/v1/")
  }

  private url(path: string): URL {
    const pathname = path.split("?")[0]
    if (!pathname || pathname.startsWith("/") || /[:\\]/.test(pathname) ||
        pathname.split("/").some(part => [".", ".."].includes(decodeURIComponent(part)))) {
      throw new Error("Expected a relative API path")
    }
    const url = new URL(path, this.base)
    if (url.origin !== this.base.origin || !url.pathname.startsWith(this.base.pathname)) {
      throw new Error("Expected a relative API path")
    }
    return url
  }

  async response(path: string, init: RequestInit = {}): Promise<Response> {
    const headers = new Headers(init.headers)
    if (this.token) headers.set("Authorization", `Bearer ${this.token}`)
    if (this.csrf && !["GET", "HEAD"].includes(init.method ?? "GET")) {
      headers.set("X-CSRF-Token", this.csrf)
    }
    const response = await fetch(this.url(path), { ...init, headers, redirect: "error", credentials: "same-origin" })
    if (!response.ok) {
      const doc = await response.json().catch(() => ({}))
      throw new PlatformError(response.status, doc?.error ?? {})
    }
    return response
  }

  private async json<T>(path: string, init?: RequestInit): Promise<T> {
    const response = await this.response(path, init)
    if (response.status === 204) return undefined as T
    return response.json()
  }

  get<T>(path: string, signal?: AbortSignal) { return this.json<T>(path, { signal }) }

  async control(signal?: AbortSignal): Promise<Control> {
    const control = await this.get<Control>("control", signal)
    this.csrf = control.csrf_token
    return control
  }

  async login(username: string, password: string) {
    const login = await this.json<{ csrf_token: string }>("auth/login", {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ username, password })
    })
    this.csrf = login.csrf_token
    return login
  }

  async logout() {
    await this.response("auth/logout", { method: "POST" })
    this.csrf = undefined
  }

  async intent(signal?: AbortSignal): Promise<Mutation> {
    const control = await this.control(signal)
    return { epoch: control.control_epoch, key: crypto.randomUUID() }
  }

  private async writeHeaders(options: WriteOptions): Promise<Headers> {
    const intent = options.intent ?? await this.intent(options.signal)
    const headers = new Headers({ "If-Control-Epoch": intent.epoch, "Idempotency-Key": intent.key })
    if (options.revision !== undefined) headers.set("If-Match", `"${options.revision}"`)
    return headers
  }

  async mutate<T = Operation>(path: string, body: unknown = {}, options: WriteOptions = {}): Promise<T> {
    const headers = await this.writeHeaders(options)
    headers.set("Content-Type", "application/json")
    return this.json<T>(path, {
      method: options.method ?? "POST", headers, body: JSON.stringify(body), signal: options.signal
    })
  }

  async upload<T = Operation>(path: string, blob: Blob, options: WriteOptions & { sha256?: string } = {}): Promise<T> {
    const headers = await this.writeHeaders(options)
    headers.set("Content-Type", "application/octet-stream")
    if (options.sha256) headers.set("X-Content-SHA256", options.sha256)
    return this.json<T>(path, { method: options.method ?? "PUT", headers, body: blob, signal: options.signal })
  }

  async waitOperation(id: string, { timeoutMs = 180000, signal, onUpdate }: {
    timeoutMs?: number; signal?: AbortSignal; onUpdate?: (op: Operation) => void
  } = {}): Promise<Operation> {
    const timeout = AbortSignal.timeout(timeoutMs)
    const observe = signal ? AbortSignal.any([signal, timeout]) : timeout
    try {
      for (;;) {
        const op = await this.get<Operation>(operation(id), observe)
        onUpdate?.(op)
        if (terminalStates.has(op.state)) return op
        await pause(350, observe)
      }
    } catch (error) {
      if (timeout.aborted && !signal?.aborted) throw new Error(`Timed out observing operation ${id}`)
      throw error
    }
  }

  wait(id: string, timeoutMs?: number) { return this.waitOperation(id, { timeoutMs }) }

  async *pages<T>(path: string, limit = 100, signal?: AbortSignal): AsyncGenerator<T> {
    let cursor = ""
    do {
      const page = await this.get<Page<T>>(withQuery(path, { limit: String(limit), cursor }), signal)
      yield* page.items
      if (page.next_cursor && page.next_cursor === cursor) throw new Error("Server did not advance cursor")
      cursor = page.next_cursor ?? ""
    } while (cursor)
  }

  async *taskOutput(id: string, stream = "stdout", offset = 0, signal?: AbortSignal): AsyncGenerator<TaskChunk> {
    const path = task(id) + "/output"
    for (;;) {
      const chunk = await this.get<{
        start: number; next: number; complete: boolean; gap: boolean; data_base64: string
      }>(withQuery(path, { stream, offset: String(offset), limit: "65536" }), signal)
      const bytes = Uint8Array.from(atob(chunk.data_base64 || ""), byte => byte.charCodeAt(0))
      if (chunk.next < offset || (bytes.length && chunk.next === offset)) throw new Error("Invalid task output cursor")
      if (bytes.length || chunk.gap || chunk.next !== offset) {
        yield { start: chunk.start, next: chunk.next, gap: chunk.gap, bytes }
      }
      offset = chunk.next
      if (chunk.complete) return
      if (!bytes.length) await pause(400, signal)
    }
  }

  async *events(lastEventId = "", signal?: AbortSignal): AsyncGenerator<PlatformEvent> {
    const headers = new Headers({ Accept: "text/event-stream" })
    if (lastEventId) headers.set("Last-Event-ID", lastEventId)
    const response = await this.response("events", { headers, signal })
    if (!response.body) throw new Error("Event stream has no body")
    const reader = response.body.pipeThrough(new TextDecoderStream()).getReader()
    let pending = ""
    let id = lastEventId
    let type = "message"
    let data: string[] = []
    try {
      for (;;) {
        const { value, done } = await reader.read()
        if (done) return
        pending += value
        let newline = pending.indexOf("\n")
        while (newline >= 0) {
          const line = pending.slice(0, newline).replace(/\r$/, "")
          pending = pending.slice(newline + 1)
          if (!line) {
            if (data.length) {
              const text = data.join("\n")
              yield { id, type, data: JSON.parse(text) }
            }
            type = "message"
            data = []
          } else {
            const colon = line.indexOf(":")
            const field = colon < 0 ? line : line.slice(0, colon)
            const value = colon < 0 ? "" : line.slice(colon + 1).replace(/^ /, "")
            if (field === "id" && !value.includes("\0")) id = value
            if (field === "event") type = value
            if (field === "data") data.push(value)
          }
          newline = pending.indexOf("\n")
        }
      }
    } finally {
      await reader.cancel().catch(() => {})
      reader.releaseLock()
    }
  }

  async browserSocket(path: string, ticketPath: string, protocol: string, signal?: AbortSignal) {
    const ticket = await this.json<StreamTicket>(ticketPath, { method: "POST", signal })
    signal?.throwIfAborted()
    const url = this.url(path)
    url.protocol = url.protocol === "https:" ? "wss:" : "ws:"
    return new WebSocket(url, [protocol, "ticket." + ticket.ticket])
  }

  socket<T>(path: string, protocol: string, connect: (url: URL, protocol: string, headers: Headers) => T): T {
    if (!this.token) throw new Error("Bearer authentication is required for a header-based socket")
    const url = this.url(path)
    url.protocol = url.protocol === "https:" ? "wss:" : "ws:"
    return connect(url, protocol, new Headers({ Authorization: `Bearer ${this.token}` }))
  }

  createMachine(spec: CreateMachine, options?: WriteOptions) { return this.mutate("machines", spec, options) }
  getMachine(id: string, signal?: AbortSignal) { return this.get<Machine>(machine(id), signal) }
  getOperation(id: string, signal?: AbortSignal) { return this.get<Operation>(operation(id), signal) }
  getService(id: string, signal?: AbortSignal) { return this.get<Service>(service(id), signal) }
  getSnapshot(id: string, signal?: AbortSignal) { return this.get<Snapshot>(snapshot(id), signal) }
  listMachines(signal?: AbortSignal) { return this.pages<Machine>("machines", 100, signal) }
  machineAction(id: string, action: "start" | "stop" | "pause" | "resume" | "wake", generation: number, options: WriteOptions) {
    return this.mutate(machine(id) + "/" + action, { expected_generation: generation }, options)
  }
  private async machineMutation(id: string, suffix: string, body: object, options: MachineWriteOptions = {}) {
    const current = options.revision === undefined || options.generation === undefined
      ? await this.getMachine(id, options.signal) : undefined
    return this.mutate(machine(id) + "/" + suffix,
      { ...body, expected_generation: options.generation ?? current?.binding_generation },
      { ...options, revision: options.revision ?? current?.revision })
  }
  startTask(id: string, spec: TaskSpec, options?: MachineWriteOptions) {
    return this.machineMutation(id, "tasks", spec, options)
  }
  getTask(id: string, signal?: AbortSignal) { return this.get<Task>(task(id), signal) }
  async cancelTask(id: string, graceSeconds = 5, options: WriteOptions = {}) {
    let revision = options.revision
    if (revision === undefined) {
      const current = await this.getTask(id, options.signal)
      revision = (await this.getMachine(current.machine_id, options.signal)).revision
    }
    return this.mutate(task(id) + "/cancel", { grace_seconds: graceSeconds }, { ...options, revision })
  }
  capture(id: string, purpose: "clone" | "recovery", label: string, options?: MachineWriteOptions) {
    return this.machineMutation(id, "snapshots", { purpose, label }, options)
  }
  clone(id: string, childName: string, options?: MachineWriteOptions) {
    return this.machineMutation(id, "clones", { child_name: childName, copy_policy: "managed_clean" }, options)
  }
  fork(id: string, childName: string, options?: MachineWriteOptions) {
    return this.machineMutation(id, "forks", { child_name: childName }, options)
  }
  restore(snapshotID: string, name: string, options?: WriteOptions) {
    return this.mutate("restores", { snapshot_id: snapshotID, name }, options)
  }
  listTokens(signal?: AbortSignal) { return this.pages<Token>("tokens", 100, signal) }
  issueToken(spec: TokenSpec, options?: WriteOptions) { return this.mutate<Token>("tokens", spec, options) }
  revokeToken(id: string, revision: number, options: WriteOptions = {}) {
    return this.mutate<{ token_id: string; revision: number; status: "revoked" }>(
      "tokens/" + segment(id), {}, { ...options, method: "DELETE", revision }
    )
  }
  async expose(id: string, spec: ServiceSpec, options: WriteOptions = {}) {
    const revision = options.revision ?? (await this.getMachine(id, options.signal)).revision
    return this.mutate(machine(id) + "/services", spec, { ...options, revision })
  }
}
