module sandbox-platform

go 1.25.0

require (
	github.com/coder/websocket v1.8.13
	github.com/mattn/go-sqlite3 v1.14.24
	github.com/modelcontextprotocol/go-sdk v1.6.1
	github.com/spf13/cobra v1.8.1
	golang.org/x/crypto v0.31.0
	golang.org/x/sys v0.41.0
	gopkg.in/yaml.v3 v3.0.1
)

require (
	github.com/google/jsonschema-go v0.4.3 // indirect
	github.com/inconshreveable/mousetrap v1.1.0 // indirect
	github.com/segmentio/asm v1.1.3 // indirect
	github.com/segmentio/encoding v0.5.4 // indirect
	github.com/spf13/pflag v1.0.5 // indirect
	github.com/yosida95/uritemplate/v3 v3.0.2 // indirect
	golang.org/x/oauth2 v0.35.0 // indirect
)
