// Build the source offer from an allowlist. Never archive local state or credentials.
import { execFileSync } from "node:child_process"
import { readdirSync, readFileSync, writeFileSync, existsSync } from "node:fs"
import { resolve, join } from "node:path"
const web = resolve(import.meta.dirname, "..")
const root = resolve(web, "..")
const dest = join(web, "dist/assets")
const lock = JSON.parse(readFileSync(join(web, "package-lock.json")))
const parts = [readFileSync(join(web, "licenses/README.md"), "utf8")]
for (const f of ["DAYTONA-COPYRIGHT", "DAYTONA-NOTICE", "DAYTONA-LICENSE", "SHADCN-LICENSE"])
  parts.push(readFileSync(join(web, "licenses", f), "utf8"))
const vnc = "web/node_modules/@novnc/novnc"
const vncDocs = join(root, vnc, "docs")
for (const name of readdirSync(vncDocs).filter(name => name.startsWith("LICENSE")))
  parts.push(readFileSync(join(vncDocs, name), "utf8"))
const bundledStyles = new Set(["node_modules/tailwindcss", "node_modules/tw-animate-css"])
for (const [dir, meta] of Object.entries(lock.packages)) {
  if (!dir || (meta.dev && !bundledStyles.has(dir)) || !existsSync(join(web, dir))) continue
  const licenseFiles = readdirSync(join(web, dir), { withFileTypes: true }).filter(
    (f) => f.isFile() && /^(licen[cs]e|copying|notice|ofl)(?:[.-]|$)/i.test(f.name),
  )
  parts.push(
    dir.replace(/^node_modules\//, "") + " " + meta.version + " (" + meta.license + ")",
    ...licenseFiles.map((f) => readFileSync(join(web, dir, f.name), "utf8")),
  )
}
writeFileSync(join(dest, "console-notices.txt"), parts.join("\n\n"))
execFileSync(
  "tar",
  [
    "--sort=name",
    "--mtime=@0",
    "--numeric-owner",
    "--owner=0",
    "--group=0",
    "--exclude=dist",
    "--exclude=__pycache__",
    "--exclude=*.egg-info",
    "-czf",
    join(dest, "console-source.tar.gz"),
    "web/src",
    "web/index.html",
    "web/tsconfig.json",
    "web/package.json",
    "web/package-lock.json",
    "web/postcss.config.mjs",
    "web/vite.config.ts",
    "web/scripts",
    "web/licenses",
    vnc,
    "web/handler.go",
    "sdk/typescript/src",
    "api",
    "cmd",
    "internal",
    "migrations",
    "guest",
    "packaging",
    "go.mod",
    "go.sum",
  ],
  { cwd: root },
)
